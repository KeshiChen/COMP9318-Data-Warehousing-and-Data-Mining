hypertools.DataGeometry
===============

.. currentmodule:: hypertools

.. autoclass:: DataGeometry
    :members:
