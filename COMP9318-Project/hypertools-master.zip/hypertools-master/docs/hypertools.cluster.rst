hypertools.cluster
==================

.. currentmodule:: hypertools

.. autofunction:: cluster