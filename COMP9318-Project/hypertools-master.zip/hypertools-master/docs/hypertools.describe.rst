hypertools.describe
===================

.. currentmodule:: hypertools

.. autofunction:: describe