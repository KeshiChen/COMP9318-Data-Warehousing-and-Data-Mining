hypertools.load
===============

.. currentmodule:: hypertools

.. autofunction:: load