hypertools.normalize
====================

.. currentmodule:: hypertools

.. autofunction:: normalize