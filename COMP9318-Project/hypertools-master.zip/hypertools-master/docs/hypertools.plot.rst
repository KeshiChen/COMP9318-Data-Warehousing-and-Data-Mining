hypertools.plot
===============

.. currentmodule:: hypertools

.. autofunction:: plot