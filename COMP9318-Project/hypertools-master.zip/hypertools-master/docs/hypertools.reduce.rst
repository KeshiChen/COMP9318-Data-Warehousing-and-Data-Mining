hypertools.reduce
=================

.. currentmodule:: hypertools

.. autofunction:: reduce