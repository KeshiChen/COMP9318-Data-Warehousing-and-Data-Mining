hypertools.tools.cluster
========================

.. currentmodule:: hypertools.tools

.. autofunction:: cluster