hypertools.tools.describe_pca
=============================

.. currentmodule:: hypertools.tools

.. autofunction:: describe_pca