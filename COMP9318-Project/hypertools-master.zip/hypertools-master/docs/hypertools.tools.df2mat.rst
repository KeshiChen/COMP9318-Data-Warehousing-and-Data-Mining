hypertools.tools.df2mat
=======================

.. currentmodule:: hypertools.tools

.. autofunction:: df2mat