hypertools.tools.format_data
============================

.. currentmodule:: hypertools.tools

.. autofunction:: format_data