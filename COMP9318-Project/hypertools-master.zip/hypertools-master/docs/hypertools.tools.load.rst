hypertools.tools.load
=====================

.. currentmodule:: hypertools.tools

.. autofunction:: load