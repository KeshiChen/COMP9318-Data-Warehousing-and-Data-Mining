hypertools.tools.normalize
==========================

.. currentmodule:: hypertools.tools

.. autofunction:: normalize