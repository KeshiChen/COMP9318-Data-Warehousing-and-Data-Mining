hypertools.tools.procrustes
===========================

.. currentmodule:: hypertools.tools

.. autofunction:: procrustes