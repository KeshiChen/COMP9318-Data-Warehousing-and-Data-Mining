hypertools.tools.reduce
=======================

.. currentmodule:: hypertools.tools

.. autofunction:: reduce