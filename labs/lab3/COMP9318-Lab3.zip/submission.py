## import modules here 

################# Question 1 #################

def multinomial_nb(training_data, sms):# do not change the heading of the function
    pass # **replace** this line with your code